"""
Augmentation helpers for handwritten character images (beyond what
ImageDataGenerator covers) — elastic distortion is a classic technique
shown to help handwriting recognition generalize (Simard et al., 2003).
"""

import numpy as np
from scipy.ndimage import gaussian_filter, map_coordinates


def elastic_transform(image, alpha=34, sigma=4, random_state=None):
    """
    Elastic deformation of a single-channel image, as used in classic MNIST
    augmentation papers. `alpha` controls displacement intensity, `sigma`
    controls smoothness of the displacement field.
    """
    if random_state is None:
        random_state = np.random.RandomState(None)

    shape = image.shape
    dx = gaussian_filter((random_state.rand(*shape) * 2 - 1), sigma, mode="constant") * alpha
    dy = gaussian_filter((random_state.rand(*shape) * 2 - 1), sigma, mode="constant") * alpha

    x, y = np.meshgrid(np.arange(shape[1]), np.arange(shape[0]))
    indices = np.reshape(y + dy, (-1, 1)), np.reshape(x + dx, (-1, 1))

    distorted = map_coordinates(image, indices, order=1, mode="constant").reshape(shape)
    return distorted


def add_salt_pepper_noise(image, amount=0.02):
    """Add salt & pepper noise to simulate scanner/photo artifacts."""
    noisy = image.copy()
    num_salt = int(amount * image.size * 0.5)
    num_pepper = int(amount * image.size * 0.5)

    coords = [np.random.randint(0, i, num_salt) for i in image.shape]
    noisy[tuple(coords)] = 255

    coords = [np.random.randint(0, i, num_pepper) for i in image.shape]
    noisy[tuple(coords)] = 0

    return noisy

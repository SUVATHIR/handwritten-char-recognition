"""Central configuration for the Handwritten Character Recognition project."""

import string

# ---- Image settings ----
IMG_SIZE = 28           # MNIST/EMNIST native size
CHANNELS = 1

# ---- MNIST ----
MNIST_CLASSES = [str(i) for i in range(10)]

# ---- EMNIST label maps ----
# 'digits' split: 10 classes, same as MNIST digits
EMNIST_DIGITS_CLASSES = [str(i) for i in range(10)]

# 'letters' split: 26 classes, label indices are 1..26 (NOT 0-indexed!), case-merged
EMNIST_LETTERS_CLASSES = list(string.ascii_uppercase)  # index 0 -> 'A' after subtracting 1 from label

# 'balanced' split: 47 classes -> digits + uppercase + a subset of lowercase
# (official NIST mapping; see https://arxiv.org/abs/1702.05373 Table II)
EMNIST_BALANCED_CLASSES = (
    list("0123456789") +
    list(string.ascii_uppercase) +
    list("abdefghnqrt")   # the 11 lowercase letters visually distinct enough to keep separate
)

# 'byclass' split: 62 classes -> digits + uppercase + lowercase (full)
EMNIST_BYCLASS_CLASSES = list("0123456789") + list(string.ascii_uppercase) + list(string.ascii_lowercase)

EMNIST_SPLIT_CLASSES = {
    "digits": EMNIST_DIGITS_CLASSES,
    "letters": EMNIST_LETTERS_CLASSES,
    "balanced": EMNIST_BALANCED_CLASSES,
    "bymerge": EMNIST_BALANCED_CLASSES,  # bymerge uses same 47-class mapping as balanced
    "byclass": EMNIST_BYCLASS_CLASSES,
}

# ---- Training defaults ----
BATCH_SIZE = 128
EPOCHS = 20
LEARNING_RATE = 1e-3
VAL_SPLIT = 0.1
RANDOM_SEED = 42

# ---- CRNN / sequence model settings ----
CRNN_IMG_HEIGHT = 32
CRNN_IMG_WIDTH = 128
CRNN_MAX_LABEL_LEN = 16          # max characters per word/line for synthetic data
CRNN_CHARSET = string.ascii_letters + string.digits + " "
CRNN_BLANK_TOKEN_INDEX = len(CRNN_CHARSET)  # CTC blank token index (last index)

# ---- Paths ----
MODELS_DIR = "models"
DATA_DIR = "data"

# Datasets

## MNIST
Auto-downloads on first use via:
```python
from tensorflow.keras.datasets import mnist
(X_train, y_train), (X_test, y_test) = mnist.load_data()
```
No manual steps needed — `src/data_loader.py` handles this.

## EMNIST
Two ways to get it:

**Option A (recommended) — `emnist` pip package** (auto-downloads and caches):
```bash
pip install emnist
```
`src/data_loader.py` will use this automatically if installed.

**Option B — manual download** from https://www.nist.gov/itl/products-and-services/emnist-dataset
Download the "Matlab format" or "binary format" archive, extract, and point
`--data_dir` in `train_cnn.py` at the extracted folder. See comments in
`src/data_loader.py::load_emnist_from_files()` for the expected file layout.

Splits available: `digits` (10 classes), `letters` (26 classes), `balanced` (47),
`bymerge` (47), `byclass` (62, full case-sensitive digits+letters).

## IAM Handwriting Database (optional — for real handwritten words/sentences with the CRNN)
- Register and download from: https://fki.tic.heia-fr.ch/databases/iam-handwriting-database
- Get the `words` or `lines` subset plus the corresponding ASCII transcription files.
- Expected format for `train_crnn.py --data_dir`: a folder of images plus a `labels.txt`
  file with `image_filename<TAB>transcription` per line — convert IAM's own label
  format to this with a small script if needed (IAM's format is documented on their site).
- If you don't have IAM access yet, use `src/crnn/synthetic_words.py` to generate
  synthetic word images from EMNIST characters — enough to get the CRNN pipeline
  working end-to-end while you wait for/consider IAM access.

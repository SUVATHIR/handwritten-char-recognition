# Handwritten Character / Alphabet Recognition

Identify handwritten digits and letters using CNNs, with an extendable path to
full word/sentence recognition via a CRNN (CNN + RNN + CTC loss) sequence model.

## Project Structure

```
handwritten_char_recognition/
├── README.md
├── requirements.txt
├── config.py                    # central config: paths, hyperparameters, label maps
├── data/                        # datasets download/cache here (auto-downloaded via TF/Keras or EMNIST pip pkg)
│   └── README.md
├── src/
│   ├── data_loader.py            # loads MNIST (digits) and EMNIST (letters/merged) as numpy arrays
│   ├── preprocess.py              # normalization, reshaping, EMNIST orientation fix, augmentation
│   ├── cnn_model.py                # CNN architectures for single-character classification
│   ├── train_cnn.py                # trains the CNN classifier on MNIST or EMNIST
│   ├── evaluate_cnn.py             # confusion matrix, per-class accuracy, misclassified samples
│   ├── predict_char.py             # predict a single character from an image file
│   ├── segment_word.py             # classical CV: segment a word image into individual characters
│   └── crnn/
│       ├── crnn_model.py           # CNN + BiLSTM + CTC model for full word/line recognition
│       ├── ctc_utils.py            # CTC encoding/decoding helpers
│       ├── synthetic_words.py      # generates synthetic word images from EMNIST characters (for CRNN training)
│       ├── train_crnn.py           # trains the CRNN on synthetic (or real) word images
│       └── predict_word.py         # run CRNN inference on a full word/line image
├── utils/
│   └── augment.py                  # rotation, shear, elastic distortion, noise
├── models/                         # trained weights saved here
└── notebooks/
    └── exploration.ipynb           # EDA / visualization starter notebook
```

## Quick Start — Single Character CNN

### 1. Install dependencies
```bash
pip install -r requirements.txt
```

### 2. Train on MNIST (digits only)
```bash
python src/train_cnn.py --dataset mnist --epochs 15
```

### 3. Train on EMNIST (letters, or digits+letters merged)
```bash
python src/train_cnn.py --dataset emnist --split letters --epochs 20
# or: --split byclass (digits+upper+lower, 62 classes) / balanced / bymerge
```

### 4. Evaluate
```bash
python src/evaluate_cnn.py --model_path models/best_cnn_emnist_letters.h5 --dataset emnist --split letters
```

### 5. Predict a single character image
```bash
python src/predict_char.py --model_path models/best_cnn_emnist_letters.h5 --image path/to/char.png --split letters
```

## Extending to Words / Sentences (CRNN)

Recognizing a full word means either:
1. **Segment-then-classify**: cut the word image into individual characters (`segment_word.py` — classical
   contour/projection-based segmentation), classify each with the CNN, concatenate results. Simple, but fails
   on cursive/touching characters.
2. **End-to-end CRNN + CTC** (recommended, more robust): a CNN extracts visual features from the whole
   word image, a BiLSTM models the character sequence, and CTC loss lets the model learn alignment between
   image columns and output characters without needing pre-segmented characters.

```bash
# Generate synthetic word images from EMNIST characters (no real word dataset needed to get started)
python src/crnn/synthetic_words.py --num_words 20000 --out data/synthetic_words

# Train the CRNN
python src/crnn/train_crnn.py --data_dir data/synthetic_words --epochs 30

# Predict on a full word/line image
python src/crnn/predict_word.py --model_path models/best_crnn.h5 --image path/to/word.png
```

For production-grade word/sentence recognition on **real handwriting**, swap the synthetic generator for a
real dataset such as **IAM Handwriting Database** (line/word level, English) — the CRNN code is dataset-agnostic
as long as you provide (image, text_label) pairs; see `src/crnn/synthetic_words.py` docstring for the expected format.

## Datasets

| Dataset | Classes | Notes |
|---|---|---|
| **MNIST** | 10 (digits 0-9) | 60k train / 10k test, 28x28 grayscale, auto-downloads via `tensorflow.keras.datasets.mnist` |
| **EMNIST** | up to 62 (digits+upper+lower) | Same 28x28 format as MNIST but rotated/flipped — `preprocess.py` fixes orientation. Splits: `digits`, `letters` (26 classes, case-insensitive), `balanced` (47), `bymerge` (47), `byclass` (62) |
| **IAM** (optional, for real-word CRNN) | N/A (free text) | Requires registration at https://fki.tic.heia-fr.ch/databases/iam-handwriting-database — not auto-downloaded |

## Notes

- EMNIST images are stored **transposed and rotated 90°** relative to MNIST — `preprocess.py::fix_emnist_orientation()` handles this automatically. Skipping this step is the most common EMNIST bug.
- For `letters` split, labels are 1-indexed (1=A/a ... 26=Z/z) and case is merged (visually similar upper/lower pairs collapsed) — see `config.py::EMNIST_LETTERS_MAP`.
- CRNN uses CTC loss, which means you don't need to pre-align characters to exact pixel positions in the label — only image + full transcription string.

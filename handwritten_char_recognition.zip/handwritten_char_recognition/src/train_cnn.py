"""
Train a CNN classifier on MNIST or EMNIST.

Usage:
    python src/train_cnn.py --dataset mnist --model simple --epochs 15
    python src/train_cnn.py --dataset emnist --split letters --model deep --epochs 20
    python src/train_cnn.py --dataset emnist --split byclass --model deep --epochs 25
"""

import argparse
import os
import sys

import numpy as np
from tensorflow.keras.callbacks import ModelCheckpoint, EarlyStopping, ReduceLROnPlateau
from tensorflow.keras.preprocessing.image import ImageDataGenerator

sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import config
from src.data_loader import load_dataset
from src.preprocess import preprocess_dataset
from src.cnn_model import get_model


def main(args):
    print(f"Loading {args.dataset} (split={args.split if args.dataset == 'emnist' else 'n/a'}) ...")
    (X_train, y_train), (X_test, y_test) = load_dataset(
        args.dataset, split=args.split, data_dir=args.data_dir
    )
    print(f"Raw shapes -> train: {X_train.shape}, test: {X_test.shape}")

    X_train, X_test = preprocess_dataset(X_train, X_test, dataset_name=args.dataset)

    if args.dataset == "emnist":
        num_classes = len(config.EMNIST_SPLIT_CLASSES[args.split])
    else:
        num_classes = 10

    print(f"Num classes: {num_classes}")

    input_shape = X_train.shape[1:]
    model = get_model(args.model, input_shape, num_classes)
    model.summary()

    os.makedirs(config.MODELS_DIR, exist_ok=True)
    tag = f"{args.dataset}" + (f"_{args.split}" if args.dataset == "emnist" else "")
    ckpt_path = os.path.join(config.MODELS_DIR, f"best_cnn_{tag}.h5")

    callbacks = [
        ModelCheckpoint(ckpt_path, monitor="val_accuracy", save_best_only=True, verbose=1),
        EarlyStopping(monitor="val_accuracy", patience=6, restore_best_weights=True),
        ReduceLROnPlateau(monitor="val_loss", factor=0.5, patience=3, min_lr=1e-6),
    ]

    if args.augment:
        datagen = ImageDataGenerator(
            rotation_range=10,
            width_shift_range=0.1,
            height_shift_range=0.1,
            zoom_range=0.1,
            validation_split=config.VAL_SPLIT,
        )
        train_gen = datagen.flow(X_train, y_train, batch_size=config.BATCH_SIZE, subset="training")
        val_gen = datagen.flow(X_train, y_train, batch_size=config.BATCH_SIZE, subset="validation")
        history = model.fit(
            train_gen, validation_data=val_gen, epochs=args.epochs, callbacks=callbacks
        )
    else:
        history = model.fit(
            X_train, y_train,
            validation_split=config.VAL_SPLIT,
            epochs=args.epochs,
            batch_size=config.BATCH_SIZE,
            callbacks=callbacks,
        )

    test_loss, test_acc = model.evaluate(X_test, y_test, verbose=0)
    print(f"\nTest accuracy: {test_acc:.4f}  |  Test loss: {test_loss:.4f}")

    np.savez_compressed(
        os.path.join(config.MODELS_DIR, f"test_split_cnn_{tag}.npz"),
        X_test=X_test, y_test=y_test
    )
    print(f"Best model saved to: {ckpt_path}")


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--dataset", required=True, choices=["mnist", "emnist"])
    parser.add_argument("--split", default="letters",
                         choices=["digits", "letters", "balanced", "bymerge", "byclass"],
                         help="Only used when --dataset emnist")
    parser.add_argument("--model", default="simple", choices=["simple", "deep"])
    parser.add_argument("--epochs", type=int, default=config.EPOCHS)
    parser.add_argument("--data_dir", default=None, help="Optional manual EMNIST data dir")
    parser.add_argument("--augment", action="store_true", help="Use light data augmentation")
    args = parser.parse_args()
    main(args)

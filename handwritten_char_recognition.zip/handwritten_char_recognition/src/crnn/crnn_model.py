"""
CRNN (CNN + BiLSTM + CTC) model for full word/line handwriting recognition.

Architecture: CNN extracts a feature map from the word image, which is reshaped
into a sequence along the width axis; a BiLSTM models character dependencies
along that sequence; a Dense+softmax layer produces per-timestep character
probabilities; CTC loss handles alignment between image columns and output text
without needing pre-segmented characters.
"""

import sys
import os

from tensorflow.keras import layers, models
import tensorflow as tf

sys.path.append(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))
import config

NUM_CLASSES = len(config.CRNN_CHARSET) + 1  # +1 for CTC blank token


def build_crnn(img_height=config.CRNN_IMG_HEIGHT, img_width=config.CRNN_IMG_WIDTH):
    """
    Builds the CRNN feature model (used for both training, wrapped with CTC loss,
    and inference). Input: (img_height, img_width, 1). Output: (time_steps, NUM_CLASSES)
    softmax probabilities per timestep.
    """
    inputs = layers.Input(shape=(img_height, img_width, 1), name="image")

    x = layers.Conv2D(32, 3, padding="same", activation="relu")(inputs)
    x = layers.MaxPooling2D(2)(x)                    # H/2, W/2

    x = layers.Conv2D(64, 3, padding="same", activation="relu")(x)
    x = layers.MaxPooling2D(2)(x)                    # H/4, W/4

    x = layers.Conv2D(128, 3, padding="same", activation="relu")(x)
    x = layers.BatchNormalization()(x)
    x = layers.MaxPooling2D((2, 1))(x)                # H/8, W/4  (preserve width resolution)

    x = layers.Conv2D(128, 3, padding="same", activation="relu")(x)
    x = layers.BatchNormalization()(x)

    # Reshape (H', W', C) -> (W', H'*C) to get a sequence along the width axis
    new_shape = (x.shape[2], x.shape[1] * x.shape[3])
    x = layers.Permute((2, 1, 3))(x)
    x = layers.Reshape(target_shape=new_shape)(x)

    x = layers.Dense(64, activation="relu")(x)
    x = layers.Bidirectional(layers.LSTM(128, return_sequences=True))(x)
    x = layers.Bidirectional(layers.LSTM(64, return_sequences=True))(x)

    outputs = layers.Dense(NUM_CLASSES, activation="softmax", name="char_probs")(x)

    return models.Model(inputs=inputs, outputs=outputs, name="crnn")


class CTCLayer(layers.Layer):
    """Custom layer that computes CTC loss and adds it to the model during training."""

    def call(self, y_true, y_pred, input_length, label_length):
        loss = tf.keras.backend.ctc_batch_cost(y_true, y_pred, input_length, label_length)
        self.add_loss(tf.reduce_mean(loss))
        return y_pred


def build_training_model(img_height=config.CRNN_IMG_HEIGHT, img_width=config.CRNN_IMG_WIDTH,
                          max_label_len=config.CRNN_MAX_LABEL_LEN):
    """
    Wraps build_crnn() with CTC loss inputs for training. Use build_crnn() alone
    (loading trained weights from this model) for inference.
    """
    crnn = build_crnn(img_height, img_width)
    time_steps = crnn.output_shape[1]

    labels = layers.Input(name="label", shape=(max_label_len,), dtype="int64")
    input_length = layers.Input(name="input_length", shape=(1,), dtype="int64")
    label_length = layers.Input(name="label_length", shape=(1,), dtype="int64")

    output = CTCLayer(name="ctc_loss")(labels, crnn.output, input_length, label_length)

    training_model = models.Model(
        inputs=[crnn.input, labels, input_length, label_length],
        outputs=output,
        name="crnn_training"
    )
    training_model.compile(optimizer="adam")
    return training_model, crnn, time_steps

"""
Run CRNN inference on a full word/line image.

Usage:
    python src/crnn/predict_word.py --model_path models/best_crnn.h5 --image path/to/word.png
"""

import argparse
import os
import sys

import numpy as np
import cv2
from tensorflow.keras.models import load_model

sys.path.append(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))
import config
from src.crnn.ctc_utils import ctc_greedy_decode


def predict(model_path, image_path, img_height=config.CRNN_IMG_HEIGHT, img_width=config.CRNN_IMG_WIDTH):
    model = load_model(model_path, compile=False)

    img = cv2.imread(image_path, cv2.IMREAD_GRAYSCALE)
    if img is None:
        raise FileNotFoundError(f"Could not read image at {image_path}")

    img = cv2.resize(img, (img_width, img_height), interpolation=cv2.INTER_AREA)
    img = img.astype("float32") / 255.0
    img = np.expand_dims(img, axis=(0, -1))  # (1, H, W, 1)

    pred_probs = model.predict(img)[0]  # (time_steps, num_classes)
    text = ctc_greedy_decode(pred_probs)

    print(f"\nPredicted text: '{text}'\n")
    return text


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--model_path", required=True)
    parser.add_argument("--image", required=True)
    args = parser.parse_args()
    predict(args.model_path, args.image)

"""
Generates synthetic word images by stitching together EMNIST character crops.
Useful for bootstrapping CRNN training without a real word/line dataset like IAM.

Output format matches what train_crnn.py expects:
    data_dir/
        images/word_00000.png, word_00001.png, ...
        labels.txt   (each line: "word_00000.png<TAB>hello")
"""

import argparse
import os
import random
import string
import sys

import numpy as np
import cv2

sys.path.append(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))
import config
from src.data_loader import load_emnist, load_mnist
from src.preprocess import fix_emnist_orientation

# A small built-in word list to sample from (extend/replace with a real dictionary file if desired)
DEFAULT_WORDS = [
    "cat", "dog", "house", "tree", "river", "mountain", "happy", "smile", "book",
    "table", "chair", "window", "garden", "flower", "bridge", "castle", "planet",
    "ocean", "forest", "guitar", "pencil", "school", "friend", "family", "music",
    "sunset", "cloud", "rainbow", "winter", "summer", "autumn", "spring", "letter",
    "number", "puzzle", "candle", "mirror", "basket", "bottle", "jacket", "pillow",
]


def build_char_bank():
    """Build a dict mapping each character -> list of EMNIST/MNIST image crops for it."""
    print("Loading EMNIST (byclass) and MNIST to build character image bank...")
    (X_letters, y_letters), _ = load_emnist(split="byclass")
    X_letters = fix_emnist_orientation(X_letters)

    (X_digits, y_digits), _ = load_mnist()  # MNIST needs no orientation fix

    bank = {c: [] for c in config.CRNN_CHARSET}

    byclass_labels = config.EMNIST_SPLIT_CLASSES["byclass"]
    for img, label_idx in zip(X_letters, y_letters):
        ch = byclass_labels[label_idx]
        if ch in bank and len(bank[ch]) < 200:  # cap per-char to keep memory reasonable
            bank[ch].append(img)

    for img, label_idx in zip(X_digits, y_digits):
        ch = str(label_idx)
        if ch in bank and len(bank[ch]) < 200:
            bank[ch].append(img)

    for c in bank:
        if len(bank[c]) == 0:
            bank[c] = None  # mark unavailable (e.g. space has no glyph)

    return bank


def render_word(word, char_bank, img_height=config.CRNN_IMG_HEIGHT, img_width=config.CRNN_IMG_WIDTH):
    """Stitch character glyphs into one word image, resized to fixed (img_height, img_width)."""
    char_h = img_height - 4
    glyphs = []
    for ch in word:
        candidates = char_bank.get(ch)
        if ch == " " or not candidates:
            glyph = np.zeros((char_h, char_h // 2), dtype=np.uint8)  # blank space
        else:
            glyph = random.choice(candidates)
            glyph = cv2.resize(glyph, (char_h, char_h), interpolation=cv2.INTER_AREA)
        glyphs.append(glyph)

    strip = np.concatenate(glyphs, axis=1) if glyphs else np.zeros((char_h, 10), dtype=np.uint8)

    canvas = np.zeros((img_height, img_width), dtype=np.uint8)
    h, w = strip.shape
    if w > img_width:
        strip = cv2.resize(strip, (img_width, char_h), interpolation=cv2.INTER_AREA)
        w = img_width
    y_off = (img_height - char_h) // 2
    canvas[y_off:y_off + char_h, :w] = strip

    return canvas


def generate(num_words, out_dir, word_list=None, seed=config.RANDOM_SEED):
    random.seed(seed)
    np.random.seed(seed)

    word_list = word_list or DEFAULT_WORDS
    char_bank = build_char_bank()

    images_dir = os.path.join(out_dir, "images")
    os.makedirs(images_dir, exist_ok=True)

    labels_path = os.path.join(out_dir, "labels.txt")
    with open(labels_path, "w") as f:
        for i in range(num_words):
            word = random.choice(word_list)
            img = render_word(word, char_bank)
            fname = f"word_{i:05d}.png"
            cv2.imwrite(os.path.join(images_dir, fname), img)
            f.write(f"{fname}\t{word}\n")

            if (i + 1) % 1000 == 0:
                print(f"  generated {i + 1}/{num_words}")

    print(f"Done. Images -> {images_dir}, labels -> {labels_path}")


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--num_words", type=int, default=5000)
    parser.add_argument("--out", required=True, help="Output directory")
    args = parser.parse_args()
    generate(args.num_words, args.out)

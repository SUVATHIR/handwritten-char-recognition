"""
CTC (Connectionist Temporal Classification) helpers: encode text labels to
integer sequences, and decode model output probabilities back to text.
"""

import numpy as np
import sys
import os

sys.path.append(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))
import config

CHARSET = config.CRNN_CHARSET
CHAR_TO_IDX = {c: i for i, c in enumerate(CHARSET)}
IDX_TO_CHAR = {i: c for i, c in enumerate(CHARSET)}
BLANK_IDX = config.CRNN_BLANK_TOKEN_INDEX


def encode_text(text, max_len=config.CRNN_MAX_LABEL_LEN):
    """Convert a text string to a fixed-length integer array (padded with -1)."""
    encoded = [CHAR_TO_IDX[c] for c in text if c in CHAR_TO_IDX]
    length = len(encoded)
    if length > max_len:
        encoded = encoded[:max_len]
        length = max_len
    padded = encoded + [-1] * (max_len - len(encoded))
    return np.array(padded, dtype=np.int64), length


def ctc_greedy_decode(pred_probs):
    """
    Greedy CTC decode: take argmax at each timestep, collapse repeats, remove blanks.

    Args:
        pred_probs: (time_steps, num_classes+1) softmax output from the CRNN

    Returns:
        Decoded string.
    """
    pred_indices = np.argmax(pred_probs, axis=-1)

    decoded = []
    prev = None
    for idx in pred_indices:
        if idx != prev and idx != BLANK_IDX:
            if idx < len(CHARSET):
                decoded.append(IDX_TO_CHAR[idx])
        prev = idx

    return "".join(decoded)

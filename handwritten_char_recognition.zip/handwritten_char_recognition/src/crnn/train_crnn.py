"""
Train the CRNN on word images (synthetic or real, e.g. IAM).

Expects data_dir/images/*.png and data_dir/labels.txt (filename<TAB>text per line),
as produced by synthetic_words.py.

Usage:
    python src/crnn/train_crnn.py --data_dir data/synthetic_words --epochs 30
"""

import argparse
import os
import sys

import numpy as np
import cv2
from sklearn.model_selection import train_test_split

sys.path.append(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))
import config
from src.crnn.crnn_model import build_training_model
from src.crnn.ctc_utils import encode_text


def load_word_dataset(data_dir):
    labels_path = os.path.join(data_dir, "labels.txt")
    images_dir = os.path.join(data_dir, "images")

    images, texts = [], []
    with open(labels_path) as f:
        for line in f:
            fname, text = line.rstrip("\n").split("\t")
            img_path = os.path.join(images_dir, fname)
            img = cv2.imread(img_path, cv2.IMREAD_GRAYSCALE)
            if img is None:
                continue
            images.append(img)
            texts.append(text)

    X = np.stack(images).astype("float32") / 255.0
    X = np.expand_dims(X, -1)  # (N, H, W, 1)
    return X, texts


def prepare_labels(texts, max_len=config.CRNN_MAX_LABEL_LEN):
    encoded = np.zeros((len(texts), max_len), dtype=np.int64)
    lengths = np.zeros((len(texts), 1), dtype=np.int64)
    for i, t in enumerate(texts):
        enc, length = encode_text(t, max_len=max_len)
        # CTC requires non-negative labels; replace padding -1 with 0 (ignored via label_length)
        enc[enc == -1] = 0
        encoded[i] = enc
        lengths[i] = length
    return encoded, lengths


def main(args):
    print(f"Loading word images from {args.data_dir} ...")
    X, texts = load_word_dataset(args.data_dir)
    print(f"Loaded {len(X)} word images")

    y_encoded, label_lengths = prepare_labels(texts)

    X_train, X_val, y_train, y_val, ll_train, ll_val = train_test_split(
        X, y_encoded, label_lengths, test_size=0.1, random_state=config.RANDOM_SEED
    )

    training_model, inference_model, time_steps = build_training_model(
        img_height=X.shape[1], img_width=X.shape[2]
    )
    inference_model.summary()

    input_length_train = np.full((len(X_train), 1), time_steps, dtype=np.int64)
    input_length_val = np.full((len(X_val), 1), time_steps, dtype=np.int64)

    os.makedirs(config.MODELS_DIR, exist_ok=True)

    history = training_model.fit(
        x=[X_train, y_train, input_length_train, ll_train],
        y=np.zeros(len(X_train)),  # dummy target; real loss added via add_loss in CTCLayer
        validation_data=(
            [X_val, y_val, input_length_val, ll_val],
            np.zeros(len(X_val))
        ),
        batch_size=config.BATCH_SIZE,
        epochs=args.epochs,
    )

    # Save the inference-only model (no CTC wrapper) for use in predict_word.py
    inference_path = os.path.join(config.MODELS_DIR, "best_crnn.h5")
    inference_model.save(inference_path)
    print(f"Inference model saved to {inference_path}")


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--data_dir", required=True)
    parser.add_argument("--epochs", type=int, default=30)
    args = parser.parse_args()
    main(args)

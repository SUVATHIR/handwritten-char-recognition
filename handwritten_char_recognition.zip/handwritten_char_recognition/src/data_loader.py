"""
Loads MNIST and EMNIST datasets as numpy arrays.

MNIST: auto-downloads via tensorflow.keras.datasets.mnist
EMNIST: uses the `emnist` pip package (auto-downloads + caches) if available,
        otherwise falls back to loading from manually-downloaded files.
"""

import os
import sys
import numpy as np

sys.path.append(os.path.dirname(os.path.abspath(__file__)))
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import config


def load_mnist():
    """Returns (X_train, y_train), (X_test, y_test) — images as (N, 28, 28) uint8."""
    from tensorflow.keras.datasets import mnist
    (X_train, y_train), (X_test, y_test) = mnist.load_data()
    return (X_train, y_train), (X_test, y_test)


def load_emnist(split="letters"):
    """
    Returns (X_train, y_train), (X_test, y_test) for the given EMNIST split.

    Uses the `emnist` pip package. Labels come back in EMNIST's native indexing:
      - 'letters' split: labels are 1..26 (subtract 1 to index into config.EMNIST_LETTERS_CLASSES)
      - other splits: labels are 0-indexed matching config.EMNIST_SPLIT_CLASSES[split]
    """
    if split not in config.EMNIST_SPLIT_CLASSES:
        raise ValueError(f"Unknown EMNIST split '{split}'. Choose from {list(config.EMNIST_SPLIT_CLASSES.keys())}")

    try:
        from emnist import extract_training_samples, extract_test_samples
    except ImportError:
        raise ImportError(
            "The 'emnist' package is required for auto-download. Install with `pip install emnist`, "
            "or use load_emnist_from_files() with a manually downloaded copy (see data/README.md)."
        )

    X_train, y_train = extract_training_samples(split)
    X_test, y_test = extract_test_samples(split)

    # Normalize 'letters' labels to be 0-indexed for consistency with everything else downstream
    if split == "letters":
        y_train = y_train - 1
        y_test = y_test - 1

    return (X_train, y_train), (X_test, y_test)


def load_emnist_from_files(data_dir, split="letters"):
    """
    Fallback loader for manually downloaded EMNIST (Matlab .mat format).
    Expects a .mat file named like 'emnist-<split>.mat' inside data_dir,
    as distributed by NIST in the Matlab-format archive.
    """
    from scipy.io import loadmat

    mat_path = os.path.join(data_dir, f"emnist-{split}.mat")
    if not os.path.exists(mat_path):
        raise FileNotFoundError(
            f"Expected {mat_path}. Download the Matlab-format EMNIST archive and extract it "
            f"into {data_dir} (see data/README.md)."
        )

    mat = loadmat(mat_path)
    data = mat["dataset"]

    X_train = data["train"][0, 0]["images"][0, 0]
    y_train = data["train"][0, 0]["labels"][0, 0].flatten()
    X_test = data["test"][0, 0]["images"][0, 0]
    y_test = data["test"][0, 0]["labels"][0, 0].flatten()

    X_train = X_train.reshape(-1, 28, 28)
    X_test = X_test.reshape(-1, 28, 28)

    if split == "letters":
        y_train = y_train - 1
        y_test = y_test - 1

    return (X_train, y_train), (X_test, y_test)


def load_dataset(name, split="letters", data_dir=None):
    """Unified entry point. name: 'mnist' or 'emnist'."""
    name = name.lower()
    if name == "mnist":
        return load_mnist()
    elif name == "emnist":
        if data_dir is not None:
            try:
                return load_emnist_from_files(data_dir, split=split)
            except Exception as e:
                print(f"[warn] manual EMNIST load failed ({e}); trying `emnist` pip package instead.")
        return load_emnist(split=split)
    else:
        raise ValueError(f"Unknown dataset '{name}'. Choose 'mnist' or 'emnist'.")


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument("--dataset", required=True, choices=["mnist", "emnist"])
    parser.add_argument("--split", default="letters")
    args = parser.parse_args()

    (X_train, y_train), (X_test, y_test) = load_dataset(args.dataset, split=args.split)
    print(f"Train: {X_train.shape}, {y_train.shape}")
    print(f"Test:  {X_test.shape}, {y_test.shape}")
    print(f"Label range: {y_train.min()} - {y_train.max()}")

"""
Classical computer-vision approach to segmenting a handwritten word image into
individual characters, so each can be classified independently by the CNN.

Works reasonably well for well-spaced print handwriting; struggles with cursive
or touching characters — for those, use the CRNN (src/crnn/) instead.
"""

import cv2
import numpy as np


def segment_characters(image_path, min_area=30, pad=4):
    """
    Segment a word image into a list of individual character crops (28x28, ready
    for the CNN), ordered left-to-right.

    Returns:
        List of (x, y, w, h, char_image) tuples, sorted by x position.
    """
    img = cv2.imread(image_path, cv2.IMREAD_GRAYSCALE)
    if img is None:
        raise FileNotFoundError(f"Could not read image at {image_path}")

    # Binarize: assume dark text on light background (standard scanned handwriting)
    _, thresh = cv2.threshold(img, 0, 255, cv2.THRESH_BINARY_INV + cv2.THRESH_OTSU)

    # Dilate slightly to merge broken strokes within a single character
    kernel = np.ones((3, 3), np.uint8)
    thresh = cv2.dilate(thresh, kernel, iterations=1)

    contours, _ = cv2.findContours(thresh, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

    boxes = []
    for c in contours:
        x, y, w, h = cv2.boundingRect(c)
        if w * h < min_area:
            continue
        boxes.append((x, y, w, h))

    boxes.sort(key=lambda b: b[0])  # left to right

    results = []
    for (x, y, w, h) in boxes:
        x0, y0 = max(0, x - pad), max(0, y - pad)
        x1, y1 = min(img.shape[1], x + w + pad), min(img.shape[0], y + h + pad)
        crop = img[y0:y1, x0:x1]

        # Make square (pad shorter side) then resize to 28x28 to match training data
        h_c, w_c = crop.shape
        size = max(h_c, w_c)
        square = np.full((size, size), 255, dtype=np.uint8)  # white background
        y_off, x_off = (size - h_c) // 2, (size - w_c) // 2
        square[y_off:y_off + h_c, x_off:x_off + w_c] = crop

        char_img = cv2.resize(square, (28, 28), interpolation=cv2.INTER_AREA)
        results.append((x, y, w, h, char_img))

    return results


if __name__ == "__main__":
    import argparse
    import matplotlib.pyplot as plt

    parser = argparse.ArgumentParser()
    parser.add_argument("--image", required=True)
    args = parser.parse_args()

    segments = segment_characters(args.image)
    print(f"Found {len(segments)} character segments")

    fig, axes = plt.subplots(1, max(len(segments), 1), figsize=(2 * len(segments), 2))
    if len(segments) == 1:
        axes = [axes]
    for ax, (x, y, w, h, char_img) in zip(axes, segments):
        ax.imshow(char_img, cmap="gray")
        ax.axis("off")
    plt.tight_layout()
    plt.savefig("segmentation_preview.png")
    print("Saved preview to segmentation_preview.png")

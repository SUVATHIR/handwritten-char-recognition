"""
Preprocessing utilities: normalization, reshaping, and the critical EMNIST
orientation fix (EMNIST images are stored transposed + rotated relative to MNIST).
"""

import numpy as np


def fix_emnist_orientation(X):
    """
    EMNIST images are stored rotated 90° and flipped compared to how they should be
    displayed/interpreted. This transposes each image back to the correct orientation.
    Apply this to EMNIST images (NOT needed for MNIST).
    """
    return np.transpose(X, (0, 2, 1))


def normalize_images(X):
    """Scale uint8 [0,255] images to float32 [0,1] and add channel dimension."""
    X = X.astype("float32") / 255.0
    if X.ndim == 3:
        X = np.expand_dims(X, axis=-1)  # (N, H, W) -> (N, H, W, 1)
    return X


def preprocess_dataset(X_train, X_test, dataset_name="mnist"):
    """Apply the full preprocessing pipeline appropriate to the dataset."""
    if dataset_name.lower() == "emnist":
        X_train = fix_emnist_orientation(X_train)
        X_test = fix_emnist_orientation(X_test)

    X_train = normalize_images(X_train)
    X_test = normalize_images(X_test)
    return X_train, X_test


def resize_to_28(img):
    """Resize an arbitrary grayscale image (numpy array) to 28x28 for inference."""
    import cv2
    if img.ndim == 3:
        img = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    img = cv2.resize(img, (28, 28), interpolation=cv2.INTER_AREA)
    return img


def invert_if_needed(img, threshold=127):
    """
    MNIST/EMNIST convention: white strokes (255) on black background (0).
    If the input image looks like black-on-white (typical of scanned/photographed
    handwriting), invert it so it matches training data convention.
    """
    if img.mean() > threshold:
        img = 255 - img
    return img

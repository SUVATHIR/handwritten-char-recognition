"""
Predict a single handwritten character from an image file.

Usage:
    python src/predict_char.py --model_path models/best_cnn_emnist_letters.h5 \
        --image path/to/char.png --dataset emnist --split letters
"""

import argparse
import os
import sys

import numpy as np
import cv2
from tensorflow.keras.models import load_model

sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import config
from src.preprocess import resize_to_28, invert_if_needed


def get_class_names(dataset, split):
    if dataset == "mnist":
        return config.MNIST_CLASSES
    return config.EMNIST_SPLIT_CLASSES[split]


def predict(model_path, image_path, dataset, split):
    model = load_model(model_path)
    class_names = get_class_names(dataset, split)

    img = cv2.imread(image_path, cv2.IMREAD_GRAYSCALE)
    if img is None:
        raise FileNotFoundError(f"Could not read image at {image_path}")

    img = invert_if_needed(img)
    img = resize_to_28(img)
    img = img.astype("float32") / 255.0
    img = np.expand_dims(img, axis=(0, -1))  # (1, 28, 28, 1)

    probs = model.predict(img)[0]
    pred_idx = int(np.argmax(probs))
    pred_label = class_names[pred_idx]

    print(f"\nPredicted character: '{pred_label}'  (confidence: {probs[pred_idx]:.2%})\n")
    top5 = np.argsort(probs)[::-1][:5]
    print("Top 5 predictions:")
    for i in top5:
        print(f"  '{class_names[i]}': {probs[i]:.2%}")

    return pred_label, probs


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--model_path", required=True)
    parser.add_argument("--image", required=True)
    parser.add_argument("--dataset", required=True, choices=["mnist", "emnist"])
    parser.add_argument("--split", default="letters")
    args = parser.parse_args()
    predict(args.model_path, args.image, args.dataset, args.split)

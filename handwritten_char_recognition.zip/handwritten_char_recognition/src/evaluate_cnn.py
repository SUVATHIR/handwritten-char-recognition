"""
Evaluate a trained CNN: confusion matrix, per-class metrics, misclassified examples.

Usage:
    python src/evaluate_cnn.py --model_path models/best_cnn_emnist_letters.h5 \
        --test_split models/test_split_cnn_emnist_letters.npz --dataset emnist --split letters
"""

import argparse
import os
import sys

import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.metrics import classification_report, confusion_matrix
from tensorflow.keras.models import load_model

sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import config


def get_class_names(dataset, split):
    if dataset == "mnist":
        return config.MNIST_CLASSES
    return config.EMNIST_SPLIT_CLASSES[split]


def evaluate(model_path, test_split_path, dataset, split, out_dir="models"):
    model = load_model(model_path)
    data = np.load(test_split_path)
    X_test, y_test = data["X_test"], data["y_test"]

    y_pred_probs = model.predict(X_test)
    y_pred = np.argmax(y_pred_probs, axis=1)

    class_names = get_class_names(dataset, split)
    present = sorted(set(y_test.tolist()) | set(y_pred.tolist()))
    labels_for_report = [class_names[i] for i in present]

    print("\nClassification Report:")
    print(classification_report(y_test, y_pred, labels=present, target_names=labels_for_report))

    cm = confusion_matrix(y_test, y_pred, labels=present)
    plt.figure(figsize=(max(8, len(present) * 0.4), max(6, len(present) * 0.4)))
    sns.heatmap(cm, annot=len(present) <= 15, fmt="d", cmap="Blues",
                xticklabels=labels_for_report, yticklabels=labels_for_report)
    plt.xlabel("Predicted")
    plt.ylabel("True")
    plt.title("Confusion Matrix")
    plt.tight_layout()
    tag = f"{dataset}" + (f"_{split}" if dataset == "emnist" else "")
    out_path = os.path.join(out_dir, f"confusion_matrix_{tag}.png")
    plt.savefig(out_path)
    print(f"Confusion matrix saved to {out_path}")

    # Show a few misclassified examples
    wrong_idx = np.where(y_pred != y_test)[0]
    if len(wrong_idx) > 0:
        sample_idx = np.random.choice(wrong_idx, size=min(9, len(wrong_idx)), replace=False)
        fig, axes = plt.subplots(3, 3, figsize=(8, 8))
        for ax, idx in zip(axes.flat, sample_idx):
            ax.imshow(X_test[idx].squeeze(), cmap="gray")
            ax.set_title(f"true={class_names[y_test[idx]]} pred={class_names[y_pred[idx]]}", fontsize=9)
            ax.axis("off")
        plt.tight_layout()
        misclass_path = os.path.join(out_dir, f"misclassified_{tag}.png")
        plt.savefig(misclass_path)
        print(f"Misclassified examples saved to {misclass_path}")


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--model_path", required=True)
    parser.add_argument("--test_split", required=True)
    parser.add_argument("--dataset", required=True, choices=["mnist", "emnist"])
    parser.add_argument("--split", default="letters")
    args = parser.parse_args()
    evaluate(args.model_path, args.test_split, args.dataset, args.split)
